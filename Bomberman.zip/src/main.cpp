#include "Game.h"
int main(){
    Game game;
    game.run();
    return 0;
}