//
// Created by mahdi on 12/1/23.
//

#include "Player.h"
Player::Player() {
        load_textures();
    this->player_position.x=player_initial_position_x;
    this->player_position.y=player_initial_position_y;
}
void Player::update_player() {
   // player_position += player_velocity;
    player_sprite.setPosition(player_position);
}

void Player::check_bounds() {
    if (player_position.x < 0) {
        player_position.x = 0;
        player_velocity.x = 0;
    } else if (player_position.x > window_width - grid_size) {
        player_position.x = window_width - grid_size;
        player_velocity.x = 0;
    }

    if (player_position.y < 0) {
        player_position.y = 0;
        player_velocity.y = 0;
    } else if (player_position.y > window_height - grid_size) {
        player_position.y = window_height - grid_size;
        player_velocity.y = 0;
    }
}

bool Player::load_textures() {
    return right_texture.loadFromFile(boy_right_addr) &&
           left_texture.loadFromFile(boy_left_addr) &&
           up_texture.loadFromFile(boy_up_addr) &&
           down_stay_texture.loadFromFile(boy_down_addr);
}



void Player::create_sprites() {
    player_sprite.setTexture(down_stay_texture);
    player_sprite.setScale(static_cast<float>(grid_size) / down_stay_texture.getSize().x,
                           static_cast<float>(grid_size) / down_stay_texture.getSize().y);
    player_sprite.setPosition(player_position);
}
void Player::handle_player_movement() {
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::W) || sf::Keyboard::isKeyPressed(sf::Keyboard::Up)) {
        this->player_velocity.y = -this->player_speed;
        this->player_sprite.setTexture(this->up_texture);
        this->player_position.y += this->player_velocity.y;
    } else if (sf::Keyboard::isKeyPressed(sf::Keyboard::S) || sf::Keyboard::isKeyPressed(sf::Keyboard::Down)) {
        this->player_velocity.y = this->player_speed;
        this->player_sprite.setTexture(this->down_stay_texture);
        this->player_position.y += this->player_velocity.y;
    } else {
        this->player_velocity.y = 0;
    }

    if (sf::Keyboard::isKeyPressed(sf::Keyboard::D) || sf::Keyboard::isKeyPressed(sf::Keyboard::Right)) {
        this->player_velocity.x = this->player_speed;
        this->player_sprite.setTexture(this->right_texture);
        this->player_position.x += this->player_velocity.x;

    } else if (sf::Keyboard::isKeyPressed(sf::Keyboard::A) || sf::Keyboard::isKeyPressed(sf::Keyboard::Left)) {
        this->player_velocity.x = -this->player_speed;
        this->player_sprite.setTexture(this->left_texture);
        this->player_position.x += this->player_velocity.x;
    } else {
        this->player_velocity.x = 0;
    }
}