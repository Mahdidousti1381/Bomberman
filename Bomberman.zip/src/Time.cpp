//
// Created by mahdi on 12/4/23.
//

#include "Time.h"


void Time::start() {
    clock_gettime(CLOCK_REALTIME, &start_time);
}

void Time::current() {
    clock_gettime(CLOCK_REALTIME, &current_time);
}

double Time::get_elapsed_time() {
    current();
    return (current_time.tv_sec - start_time.tv_sec);
}


void Time::remaining_time(int &game_duration) {
    if (remained_time > 0) {
        remained_time = game_duration - static_cast<int>(get_elapsed_time());
        minutes_remained = floor(remained_time / 60);
        seconds_remained = floor(remained_time % 60);
        if (minutes_remained < 10 && seconds_remained < 10) {
            remaining_time_string = "0" + std::to_string(minutes_remained) + ":0" + std::to_string(seconds_remained);
        } else if (minutes_remained < 10 && seconds_remained >= 10) {
            remaining_time_string = "0" + std::to_string(minutes_remained) + ":" + std::to_string(seconds_remained);
        } else if (minutes_remained >= 10 && seconds_remained < 10) {
            remaining_time_string = std::to_string(minutes_remained) + ":0" + std::to_string(seconds_remained);
        } else if (minutes_remained >= 10 && seconds_remained >= 10) {
            remaining_time_string = std::to_string(minutes_remained) + ":" + std::to_string(seconds_remained);
        }
    }else
        stop();
}

void Time::stop() {
    remained_time = 0;
}
