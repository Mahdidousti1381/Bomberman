//
// Created by mahdi on 12/3/23.
//

#include "Key.h"

Key::Key(int keynum) {
    load_texture();
    create_sprite(keynum);
}

bool Key::load_texture() {
    return key1_texture.loadFromFile(key1_addr) &&
           key2_texture.loadFromFile(key1_addr) &&
           key3_texture.loadFromFile(key1_addr);
}
void Key::create_sprite(int keynum) {
    if(keynum == 1){
    key_sprite.setTexture(key1_texture);
    key_sprite.setScale(static_cast<float>(grid_size) / (2.0 * key1_texture.getSize().x),
                         static_cast<float>(grid_size)/ ( 2.0 * key1_texture.getSize().y));
    }
    if(keynum == 2){
        key_sprite.setTexture(key2_texture);
        key_sprite.setScale(static_cast<float>(grid_size) / (2.0 * key2_texture.getSize().x),
                            static_cast<float>(grid_size) / (2.0 * key2_texture.getSize().y));
    }if(keynum == 3){
        key_sprite.setTexture(key3_texture);
        key_sprite.setScale(static_cast<float>(grid_size) / (2.0 * key3_texture.getSize().x),
                            static_cast<float>(grid_size) / (2.0 * key3_texture.getSize().y));
    }
}

