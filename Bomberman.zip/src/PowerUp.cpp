//
// Created by mahdi on 12/5/23.
//

#include "PowerUp.h"

PowerUp::PowerUp() {
    load_texture();
    create_sprite();
}

bool PowerUp::load_texture() {
    return heart_texture.loadFromFile(heart_addr) &&
           speedup_texture.loadFromFile(speedup_addr);
}

void PowerUp::create_sprite() {
    heart_sprite.setTexture(heart_texture);
    heart_sprite.setScale(static_cast<float>(grid_size) / heart_texture.getSize().x,
                          static_cast<float>(grid_size) / heart_texture.getSize().y);
    speedup_sprite.setTexture(speedup_texture);
    speedup_sprite.setScale(static_cast<float>(grid_size) / speedup_texture.getSize().x,
                            static_cast<float>(grid_size) / speedup_texture.getSize().y);
}

void PowerUp::create_center_rectangle() {
    heart_center_rectangle.setSize(sf::Vector2f(grid_size / 2, grid_size / 2));
    speedup_center_rectangle.setSize(sf::Vector2f(grid_size / 2, grid_size / 2));
    sf::Vector2f heart_rectangle_center;
    sf::Vector2f speedup_rectangle_center;

    heart_rectangle_center.x = heart_sprite.getPosition().x + heart_sprite.getGlobalBounds().width/4.f;
    heart_rectangle_center.y = heart_sprite.getPosition().y + heart_sprite.getGlobalBounds().width/4.f;

    speedup_rectangle_center.x = speedup_sprite.getPosition().x + speedup_sprite.getGlobalBounds().width / 4.f;
    speedup_rectangle_center.y = speedup_sprite.getPosition().y + speedup_sprite.getGlobalBounds().width / 4.f;

    speedup_center_rectangle.setPosition(speedup_rectangle_center);
    heart_center_rectangle.setPosition(heart_rectangle_center);

}
