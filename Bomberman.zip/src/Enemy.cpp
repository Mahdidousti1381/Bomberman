//
// Created by mahdi on 12/5/23.
//

#include "Enemy.h"

Enemy::Enemy(char enemy_type) {
    load_textures(enemy_type);
    char random_v_direction = create_random_vertical_direction();
    char random_h_direction = create_random_horizontal_direction();
    create_sprites(enemy_type, random_v_direction, random_h_direction);

}

void Enemy::update_enemy(char enemy_type) {
    //enemy_position += enemy_velocity;
    //enemy_sprite.setPosition(enemy_position);
    if (enemy_type == 'H') {
        h_enemy_sprite.setPosition(enemy_position);
        set_enemy_center_rectangle();
        enemy_center_rectangle.setPosition(enemy_position.x + h_enemy_sprite.getGlobalBounds().width / 4,
                                           enemy_position.y + h_enemy_sprite.getGlobalBounds().width / 4);
    } else if (enemy_type == 'V') {
        v_enemy_sprite.setPosition(enemy_position);
        set_enemy_center_rectangle();
        enemy_center_rectangle.setPosition(enemy_position.x + v_enemy_sprite.getGlobalBounds().width / 4,
                                           enemy_position.y + v_enemy_sprite.getGlobalBounds().width / 4);
    }
}

void Enemy::handle_enemy_movement() {
    if (this->direction == 'l') {
        // enemy_velocity.x = -enenmy_speed;
        enemy_position.x += enemy_velocity.x;
    } else if (this->direction == 'r') {
        //  enemy_velocity.x = enenmy_speed;
        enemy_position.x += enemy_velocity.x;
    } else if (this->direction == 'u') {
        //  enemy_velocity.y = -enenmy_speed;
        enemy_position.y += enemy_velocity.y;
    } else if (this->direction == 'd') {
        // enemy_velocity.y = enenmy_speed;
        enemy_position.y += enemy_velocity.y;
    }
}


bool Enemy::load_textures(char enemy_type) {
    if (enemy_type == 'H') {
        h_enemy_left_texture.loadFromFile(girl_left_addr);
        h_enemy_right_texture.loadFromFile(girl_right_addr);
    } else if (enemy_type == 'V') {
        v_enemy_up_texture.loadFromFile(girl_up_addr);
        v_enemy_down_texture.loadFromFile(girl_down_addr);
    }
}

void Enemy::create_sprites(char enemy_type, char vertical_direction, char horizontal_direction) {
    if (enemy_type == 'H') {
        if (horizontal_direction == 'l') {
            h_enemy_sprite.setTexture(h_enemy_left_texture);
            h_enemy_sprite.setScale(static_cast<float>(grid_size) / h_enemy_left_texture.getSize().x,
                                    static_cast<float>(grid_size) / h_enemy_left_texture.getSize().y);
            h_enemy_sprite.setTexture(h_enemy_left_texture);
            direction = horizontal_direction;
            enemy_velocity.x = -enemies_speed;
            enemy_velocity.y = 0;
        } else if (horizontal_direction == 'r') {
            h_enemy_sprite.setTexture(h_enemy_right_texture);
            h_enemy_sprite.setScale(static_cast<float>(grid_size) / h_enemy_right_texture.getSize().x,
                                    static_cast<float>(grid_size) / h_enemy_right_texture.getSize().y);
            h_enemy_sprite.setTexture(h_enemy_right_texture);
            direction = horizontal_direction;
            enemy_velocity.x = enemies_speed;
            enemy_velocity.y = 0;
        }
    } else if (enemy_type == 'V') {
        if (vertical_direction == 'u') {
            v_enemy_sprite.setTexture(v_enemy_up_texture);
            v_enemy_sprite.setScale(static_cast<float>(grid_size) / v_enemy_up_texture.getSize().x,
                                    static_cast<float>(grid_size) / v_enemy_up_texture.getSize().y);
            v_enemy_sprite.setTexture(v_enemy_up_texture);
            direction = vertical_direction;
            enemy_velocity.y = -enemies_speed;
            enemy_velocity.x = 0;
        } else if (vertical_direction == 'd') {
            v_enemy_sprite.setTexture(v_enemy_down_texture);
            v_enemy_sprite.setScale(static_cast<float>(grid_size) / v_enemy_down_texture.getSize().x,
                                    static_cast<float>(grid_size) / v_enemy_down_texture.getSize().y);
            v_enemy_sprite.setTexture(v_enemy_down_texture);
            direction = vertical_direction;
            enemy_velocity.y = enemies_speed;
            enemy_velocity.x = 0;
        }

    }

}

char Enemy::create_random_vertical_direction() {
    int random_index = rand() % 2;
    switch (random_index) {
        case 0:
            return 'u';
        case 1:
            return 'd';
    }
}

char Enemy::create_random_horizontal_direction() {
    int random_index = rand() % 2;
    switch (random_index) {
        case 0:
            return 'l';
        case 1:
            return 'r';
    }
}

void Enemy::check_bounds() {
    if (enemy_position.x < 0) {
        enemy_position.x = 0;
        enemy_velocity.x = -enemy_velocity.x;
        this->h_enemy_sprite.setTexture(this->h_enemy_right_texture);
    } else if (enemy_position.x > window_width - grid_size) {
        enemy_position.x = window_width - grid_size;
        enemy_velocity.x = -enemy_velocity.x;
        this->h_enemy_sprite.setTexture(this->h_enemy_left_texture);
    }
    if (enemy_position.y < 0) {
        enemy_position.y = 0;
        enemy_velocity.y = -enemy_velocity.y;
        this->v_enemy_sprite.setTexture(this->v_enemy_down_texture);

    } else if (enemy_position.y > window_height - grid_size) {
        enemy_position.y = window_height - grid_size;
        enemy_velocity.y = -enemy_velocity.y;
        this->v_enemy_sprite.setTexture(this->v_enemy_up_texture);
    }
}

void Enemy::set_enemy_center_rectangle() {
    sf::Vector2f center_rect_size;
    center_rect_size.x = grid_size / 2;
    center_rect_size.y = grid_size / 2;
    enemy_center_rectangle.setSize(center_rect_size);
}

