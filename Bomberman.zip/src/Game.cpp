//
// Created by mahdi on 12/1/23.
//
#include "Game.h"


Game::Game() {
    window_size_detector();
    window.create(sf::VideoMode(window_width + bar_window_width, window_height), game_name);
    window.setFramerateLimit(200);
    load_textures();
    create_sprites();
    load_music();
    game_time->start();
}

void Game::run() {
    music.play();
    while (window.isOpen()) {
        handleEvents();
        update();
        render();
    }
}

void Game::bomber() {
    if (bombs.size() < max_bombs) {
        Bomb *bomb = new Bomb();
        if (bomb_cooldown.getElapsedTime().asSeconds() >= bomb_cooldown_duration) {

            float player_center_x = human->player_position.x + player_grid_size / 2;
            float player_center_y = human->player_position.y + player_grid_size / 2;
            int grid_x = std::round(static_cast<int>(player_center_x / grid_size));
            int grid_y = std::round(static_cast<int>(player_center_y / grid_size));
            bomb->bomb_position.x = grid_x * grid_size;
            bomb->bomb_position.y = grid_y * grid_size;
            bomb->bomb_sprite.setPosition(bomb->bomb_position);
            bomb->find_explosion_area();
            bomb->time_created = std::chrono::system_clock::now();
            bombs.push_back(bomb);
            bomb_cooldown.restart();
        }
    }
}

void Game::destroy_barriers_and_enemies(Bomb *bomb) {
    std::vector<Enemy *> killed_v_enemies;
    std::vector<Enemy *> killed_h_enemies;
    std::vector<Barrier *> exploding_barriers;
    for (Barrier *exploding_barrier: barriers) {

        for (int i = 0; i < 5; i++) {
            if (exploding_barrier->barrier_sprite.getGlobalBounds().intersects(
                    bomb->explosion_area[i].getGlobalBounds())) {
                exploding_barriers.push_back(exploding_barrier);
            }
        }
    }
    for (Enemy *killed_v_enemy: v_enemies) {
        for (int i = 0; i < 5; i++) {
            if (killed_v_enemy->v_enemy_sprite.getGlobalBounds().intersects(
                    bomb->explosion_area[i].getGlobalBounds())) {
                killed_v_enemies.push_back(killed_v_enemy);
                break;
            }
        }
    }
    for (Enemy *killed_h_enemy: h_enemies) {
        for (int i = 0; i < 5; i++) {
            if (killed_h_enemy->h_enemy_sprite.getGlobalBounds().intersects(
                    bomb->explosion_area[i].getGlobalBounds())) {
                killed_h_enemies.push_back(killed_h_enemy);
                break;
            }
        }
    }
    for (Barrier *exploding_barrier: exploding_barriers) {
        barriers.erase(std::remove(barriers.begin(), barriers.end(), exploding_barrier), barriers.end());
        delete exploding_barrier;
    }
    for (Enemy *killed_v_enemy: killed_v_enemies) {
        v_enemies.erase(std::remove(v_enemies.begin(), v_enemies.end(), killed_v_enemy), v_enemies.end());
        delete killed_v_enemy;
    }
    for (Enemy *killed_h_enemy: killed_h_enemies) {
        h_enemies.erase(std::remove(h_enemies.begin(), h_enemies.end(), killed_h_enemy), h_enemies.end());
        delete killed_h_enemy;
    }
}

void Game::bomb_explosion() {
    std::vector<Bomb *> bombsToRemove;
    for (int i = 0; i < bombs.size(); i++) {
        Bomb *bomb = bombs[i];
        if (std::chrono::duration_cast<std::chrono::milliseconds>(
                std::chrono::system_clock::now() - bomb->time_created).count() >= bomb_explosion_time - 300) {
            bomb->show_animation = true;
            if (std::chrono::duration_cast<std::chrono::milliseconds>(
                    std::chrono::system_clock::now() - bomb->time_created).count() >= bomb_explosion_time) {
                destroy_barriers_and_enemies(bomb);
                decrease_health_by_bomb(bomb);
                bombsToRemove.push_back(bomb);
                bomb->show_animation = false;
            }
        }
    }
    for (Bomb *bombToRemove: bombsToRemove) {
        bombs.erase(std::remove(bombs.begin(), bombs.end(), bombToRemove), bombs.end());
        delete bombToRemove;
    }
}

void Game::load_textures() {
    if (!human->load_textures()) {
        std::cout << "Failed to load player's images." << std::endl;
        window.close();
    }

    if (!background_texture.loadFromFile(grass_addr)) {
        std::cout << "Failed to load background image." << std::endl;
        window.close();
    }
    if (!sidebar_texture.loadFromFile(sidebar_addr)) {
        std::cout << "could not load sidebar texture!" << std::endl;
        window.close();
    }

}

void Game::create_sprites() {
    background_sprite.setTexture(background_texture);
    background_sprite.setScale(static_cast<float>(grid_size) / background_texture.getSize().x,
                               static_cast<float>(grid_size) / background_texture.getSize().y);
    create_barriers();
    select_random_barriers();
    set_keys_position();
    set_powerup_position();
    human->create_sprites();
}

void Game::handleEvents() {
    sf::Event event;
    while (window.pollEvent(event)) {
        if (event.type == sf::Event::Closed) {
            window.close();
        }
    }
}

void Game::update_enemies() {
    for (int i = 0; i < v_enemies.size(); i++) {
        v_enemies[i]->handle_enemy_movement();
        v_enemies[i]->check_bounds();
        check_v_enemy_collision_with_barriers(v_enemies[i]);
        v_enemies[i]->update_enemy('V');

    }
    for (int i = 0; i < h_enemies.size(); i++) {
        h_enemies[i]->handle_enemy_movement();
        h_enemies[i]->check_bounds();
        check_h_enemy_collision_with_barriers(h_enemies[i]);
        h_enemies[i]->update_enemy('H');
    }
}

void Game::update() {
    if (!music.Playing)
        music.play();
    window_sidebar();
    timer();
    human->handle_player_movement();
    if (sf::Keyboard::isKeyPressed(sf::Keyboard::X)) {
        bomber();
    }
    human->check_bounds();
    player_collision_check();
    check_player_enemy_collision();
    grab_key();
    grab_powerup();
    if (pass_door()) {
        won = true;
    }
    update_enemies();
    bomb_explosion();
    human->update_player();
}

void Game::render_background() {
    for (int x = 0; x < num_tiles_x; x++) {
        for (int y = 0; y < num_tiles_y; y++) {
            background_sprite.setPosition(static_cast<float>(x * grid_size), static_cast<float>(y * grid_size));
            window.draw(background_sprite);
        }
    }
}

void Game::create_barriers() {
    for (int i = 0; i < WINDOW.size(); i++) {
        if (WINDOW[i].character == 'B' || WINDOW[i].character == 'D') {
            Barrier *barrier = new Barrier();
            barrier->barrier_sprite.setPosition(static_cast<float>(WINDOW[i].col * grid_size),
                                                static_cast<float>(WINDOW[i].row * grid_size));
            barriers.push_back(barrier);
        }
        if (WINDOW[i].character == 'P') {
            Barrier *barrier_p = new Barrier();
            barrier_p->barrier_p_sprite.setPosition(static_cast<float>(WINDOW[i].col * grid_size),
                                                    static_cast<float>(WINDOW[i].row * grid_size));
            p_barriers.push_back(barrier_p);
        }
        if (WINDOW[i].character == 'V') {
            Enemy *v_enemy = new Enemy('V');
            v_enemy->v_enemy_sprite.setPosition(static_cast<float>(WINDOW[i].col * grid_size),
                                                static_cast<float>(WINDOW[i].row * grid_size));
            v_enemy->enemy_position.x = static_cast<float>(WINDOW[i].col * grid_size);
            v_enemy->enemy_position.y = static_cast<float>(WINDOW[i].row * grid_size);
            v_enemies.push_back(v_enemy);
        }
        if (WINDOW[i].character == 'H') {
            Enemy *h_enemy = new Enemy('H');
            h_enemy->h_enemy_sprite.setPosition(static_cast<float>(WINDOW[i].col * grid_size),
                                                static_cast<float>(WINDOW[i].row * grid_size));
            h_enemy->enemy_position.x = static_cast<float>(WINDOW[i].col * grid_size);
            h_enemy->enemy_position.y = static_cast<float>(WINDOW[i].row * grid_size);
            h_enemies.push_back(h_enemy);
        }
        if (WINDOW[i].character == 'D') {
            door->door_sprite.setPosition(static_cast<float>(WINDOW[i].col * grid_size),
                                          static_cast<float>(WINDOW[i].row * grid_size));
        }
    }
}

void Game::render_barriers() {
    for (int i = 0; i < barriers.size(); i++) {
        window.draw(barriers[i]->barrier_sprite);
    }

    for (int i = 0; i < p_barriers.size(); i++) {
        window.draw(p_barriers[i]->barrier_p_sprite);
    }
}

void Game::render_enemies() {
    for (int i = 0; i < v_enemies.size(); i++) {
        window.draw(v_enemies[i]->v_enemy_sprite);
    }
    for (int i = 0; i < h_enemies.size(); i++) {
        window.draw(h_enemies[i]->h_enemy_sprite);
    }
}

void Game::render_keys() {
    for (int i = 0; i < keys.size(); i++) {
        window.draw(keys[i]->key_sprite);

    }
}

void Game::render_powerups() {
    for (int i = 0; i < hearts.size(); i++) {
        window.draw(hearts[i]->heart_sprite);
    }
    if (speedups_count == num_speedups) {
        window.draw(speedup->speedup_sprite);
    }
}

void Game::render_animation() {
    for (int i = 0; i < bombs.size(); i++) {
        if (bombs[i]->show_animation)
            for (int j = 0; j < bombs[i]->exploding_animations.size(); j++)
                window.draw(bombs[i]->exploding_animations[j]->animation_sprite);
    }
}

void Game::render_life_and_keys_count() {
    for (int i = 0; i < human->health; i++) {
        if (heart_texture.loadFromFile(heart_addr)) {
            sf::Sprite heart_sprite;
            heart_sprite.setTexture(heart_texture);
            heart_sprite.setScale(0.75, 0.75);
            heart_sprite.setPosition(sf::Vector2f(1030.f + 80.f * i, 380.f));
            window.draw(heart_sprite);
        }
    }
    for (int i = 0; i < human->grabed_keys_count; i++) {
        if (key_texture.loadFromFile(key1_addr)) {
            sf::Sprite key_sprite;
            key_sprite.setTexture(key_texture);
            key_sprite.setScale(1.1, 1.1);
            key_sprite.setPosition(sf::Vector2f(1030.f + 80.f * i, 675.f));
            window.draw(key_sprite);
        }
    }
    if (human->player_speed == player_upgraded_speed) {
        if (speedup_texture.loadFromFile(speedup_addr)) {
            sf::Sprite speedup_sprite;
            speedup_sprite.setTexture(speedup_texture);
            speedup_sprite.setScale(1.1, 1.1);
            speedup_sprite.setPosition(sf::Vector2f(1090.f, 875.f));
            window.draw(speedup_sprite);
        }
    }
}

void Game::render() {
    window.clear();
    render_background();
    window.draw(sidebar_background);
    window.draw(time_text->remaining_time_text);
    //window.draw(lives_text->lives_count_text);
    //window.draw(keys_text->keys_count_text);
    render_life_and_keys_count();
    render_keys();
    render_powerups();
    window.draw(door->door_sprite);
    render_barriers();
    render_enemies();
    render_animation();
    for (int i = 0; i < bombs.size(); i++) {
        window.draw(bombs[i]->bomb_sprite);
    }
    if (!won && !game_over) {
        window.draw(human->player_sprite);
    }
    end_game();
    window.display();
}

std::vector<Game::Ground> Game::get_game_ground() {

    const char *filename = ground_text_addr;
    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Unable to open file: " << filename << std::endl;
        abort();
    }
    std::vector<Ground> ground;
    std::string time_str;
    getline(file, time_str);
    game_time_minutes = stoi(time_str.substr(0, 2));
    game_time_seconds = stoi(time_str.substr(3, 2));
    game_duration = game_time_minutes * 60 + game_time_seconds;
    char ch;
    int row = 0;
    int col = 0;
    while (file.get(ch)) {
        if (ch == '\n') {
            row++;
            col = 0;
        } else {
            Ground info;
            info.character = ch;
            info.row = row;
            info.col = col;
            col++;
            ground.push_back(info);
        }
    }
    return ground;
}

void Game::window_size_detector() {
    Ground Window;
    WINDOW = get_game_ground();
    int max_row = 0;
    int max_col = 0;
    for (int i = 0; i < WINDOW.size(); i++) {
        if (WINDOW[i].row >= max_row)
            max_row = WINDOW[i].row;
        if (WINDOW[i].col >= max_col)
            max_col = WINDOW[i].col;
    }
    num_tiles_x = max_col + 1;
    num_tiles_y = max_row + 1;
}

bool Game::is_horizontaly_adjacent(std::vector<float> bounds) {
    float creature_top = bounds[2];
    float creature_bottom = bounds[3];
    float barrier_top = bounds[6];
    float barrier_bottom = bounds[7];
    bool horizontal_adjacency = ((creature_top < barrier_bottom - 1) && (creature_top >= barrier_top))
                                ||
                                ((creature_bottom > barrier_top + 1) && (creature_bottom <= barrier_bottom))
                                ||
                                ((creature_top == barrier_top) && (creature_bottom == barrier_bottom));
    if (horizontal_adjacency)
        return true;
    else
        return false;
}

bool Game::is_verticaly_adjacent(std::vector<float> bounds) {
    float creature_left = bounds[0];
    float creature_right = bounds[1];
    float barrier_left = bounds[4];
    float barrier_right = bounds[5];

    bool vertical_adjacency = ((creature_left < barrier_right - 1) && (creature_left >= barrier_left))
                              ||
                              ((creature_right > barrier_left + 1) && (creature_right <= barrier_right))
                              ||
                              ((creature_left == barrier_left) && (creature_right == barrier_right));

    if (vertical_adjacency)
        return true;
    else
        return false;
}


char Game::detect_intersection(sf::Sprite static_sprite, sf::Sprite moving_sprite) {

// Check for intersection
    sf::FloatRect creature_bounds = moving_sprite.getGlobalBounds();
    sf::FloatRect barrier_bounds = static_sprite.getGlobalBounds();

    if (creature_bounds.intersects(barrier_bounds)) {
        std::vector<float> bounds;
        float creature_left = creature_bounds.left;
        bounds.push_back(creature_left);
        float creature_right = creature_bounds.left + creature_bounds.width;
        bounds.push_back(creature_right);
        float creature_top = creature_bounds.top;
        bounds.push_back(creature_top);
        float creature_bottom = creature_bounds.top + creature_bounds.height;
        bounds.push_back(creature_bottom);
        float barrier_left = barrier_bounds.left;
        bounds.push_back(barrier_left);
        float barrier_right = barrier_bounds.left + barrier_bounds.width;
        bounds.push_back(barrier_right);
        float barrier_top = barrier_bounds.top;
        bounds.push_back(barrier_top);
        float barrier_bottom = barrier_bounds.top + barrier_bounds.height;
        bounds.push_back(barrier_bottom);
        bool left_intersection =
                (creature_right >= barrier_left) && (creature_right <= barrier_left + human->player_speed * 3);
        bool right_intersection =
                (creature_left <= barrier_right) && (creature_left >= barrier_right - human->player_speed * 3);
        bool top_intersection =
                (creature_bottom >= barrier_top) && (creature_bottom <= barrier_top + human->player_speed * 3);
        bool down_intersection =
                (creature_top <= barrier_bottom) && (creature_top >= barrier_bottom - human->player_speed * 3);

        if ((is_horizontaly_adjacent(bounds)) && left_intersection) {
            return 'L';
        } else if ((is_horizontaly_adjacent(bounds)) && right_intersection) {
            return 'R';
        } else if (is_verticaly_adjacent(bounds) && top_intersection) {
            return 'T';
        } else if ((is_verticaly_adjacent(bounds)) && down_intersection) {
            return 'B';
        }
    } else {
        return 'N';
    }
}

void Game::player_collision_check() {
    for (int i = 0; i < barriers.size(); i++) {
        manage_player_collision(barriers[i]->barrier_sprite);
    }
    for (int i = 0; i < p_barriers.size(); i++) {
        manage_player_collision(p_barriers[i]->barrier_p_sprite);
    }
}

void Game::manage_player_collision(sf::Sprite barrier) {
    char intersection_direction = detect_intersection(barrier, human->player_sprite);
    if (intersection_direction == 'L') {
        human->player_velocity.x = 0;
        human->player_position.x = barrier.getGlobalBounds().left - human->player_sprite.getGlobalBounds().width;
    } else if (intersection_direction == 'R') {
        human->player_velocity.x = 0;
        human->player_position.x = barrier.getGlobalBounds().left + barrier.getGlobalBounds().width;
    } else if (intersection_direction == 'T') {
        human->player_velocity.y = 0;
        human->player_position.y = barrier.getGlobalBounds().top - human->player_sprite.getGlobalBounds().width;
    } else if (intersection_direction == 'B') {
        human->player_velocity.y = 0;
        human->player_position.y = barrier.getGlobalBounds().top + barrier.getGlobalBounds().width;
    } else if (intersection_direction == 'N') {
        return;
    }
}


void Game::select_random_barriers() {
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dis(0, barriers.size() - 1);
    std::vector<Barrier *> selected_barriers;

    while (selected_barriers.size() < num_key_barriers + num_hearts + num_speedups) {
        int random_index = dis(gen);
        Barrier *random_barrier = barriers[random_index];

        bool is_unique = true;
        for (Barrier *barrier: selected_barriers) {
            if (barrier == random_barrier) {
                is_unique = false;
                break;
            }
        }
        if (is_unique) {
            selected_barriers.push_back(random_barrier);
        }
    }
    for (int i = 0; i < num_key_barriers; i++)
        selected_barriers_for_keys.push_back(selected_barriers[i]);
    for (int i = num_key_barriers; i < num_key_barriers + num_hearts; i++)
        selected_barriers_for_hearts.push_back(selected_barriers[i]);
    for (int i = num_key_barriers + num_hearts; i < num_key_barriers + num_hearts + num_speedups; i++)
        selected_barriers_for_speedups.push_back(selected_barriers[i]);
}

void Game::set_keys_position() {

    float center_position1_x = selected_barriers_for_keys[0]->barrier_sprite.getGlobalBounds().left + (grid_size / 4);
    float center_position1_y = selected_barriers_for_keys[0]->barrier_sprite.getGlobalBounds().top + (grid_size / 4);
    float center_position2_x = selected_barriers_for_keys[1]->barrier_sprite.getGlobalBounds().left + (grid_size / 4);
    float center_position2_y = selected_barriers_for_keys[1]->barrier_sprite.getGlobalBounds().top + (grid_size / 4);
    float center_position3_x = selected_barriers_for_keys[2]->barrier_sprite.getGlobalBounds().left + (grid_size / 4);
    float center_position3_y = selected_barriers_for_keys[2]->barrier_sprite.getGlobalBounds().top + (grid_size / 4);

    for (int i = 0; i < num_key_barriers; i++) {
        Key *key = new Key(i + 1);
        if (i == 0)
            key->key_sprite.setPosition(center_position1_x, center_position1_y);
        if (i == 1)
            key->key_sprite.setPosition(center_position2_x, center_position2_y);
        if (i == 2)
            key->key_sprite.setPosition(center_position3_x, center_position3_y);
        keys.push_back(key);
    }
}

void Game::set_powerup_position() {
    for (int i = 0; i < num_hearts; i++) {
        PowerUp *heart = new PowerUp;
        heart->heart_sprite.setPosition(selected_barriers_for_hearts[i]->barrier_sprite.getGlobalBounds().left,
                                        selected_barriers_for_hearts[i]->barrier_sprite.getGlobalBounds().top);
        heart->create_center_rectangle();
        hearts.push_back(heart);
    }
    for (int j = 0; j < num_speedups; j++) {
        speedup->speedup_sprite.setPosition(selected_barriers_for_speedups[j]->barrier_sprite.getGlobalBounds().left,
                                            selected_barriers_for_speedups[j]->barrier_sprite.getGlobalBounds().top);
        speedup->create_center_rectangle();
    }
}

void Game::grab_key() {

    for (Key *grabbed_key: keys) {
        if (human->player_sprite.getGlobalBounds().intersects(grabbed_key->key_sprite.getGlobalBounds())) {
            keys.erase(std::remove(keys.begin(), keys.end(), grabbed_key), keys.end());
            delete grabbed_key;
            human->grabed_keys_count++;
        }
    }

}

void Game::grab_powerup() {
    for (PowerUp *grabbed_heart: hearts) {
        if (human->player_sprite.getGlobalBounds().intersects(
                grabbed_heart->heart_center_rectangle.getGlobalBounds())) {
            hearts.erase(std::remove(hearts.begin(), hearts.end(), grabbed_heart), hearts.end());
            delete grabbed_heart;
            if (human->health < 3)
                human->health++;
        }
    }
    if (speedups_count == num_speedups) {
        if (human->player_sprite.getGlobalBounds().intersects(speedup->speedup_center_rectangle.getGlobalBounds())) {
            delete speedup;
            human->player_speed = player_upgraded_speed;
            speedups_count--;
        }
    }
}

bool Game::pass_door() {
    sf::RectangleShape door_center_rectangle(sf::Vector2f(grid_size / 2, grid_size / 2));
    sf::Vector2f door_center;
    sf::Vector2f door_size;
    door_center.x = door->door_sprite.getPosition().x + door->door_sprite.getGlobalBounds().width / 4.f;
    door_center.y = door->door_sprite.getPosition().y + door->door_sprite.getGlobalBounds().width / 4.f;
    door_center_rectangle.setPosition(door_center);
    door_size.x = door->door_sprite.getGlobalBounds().width / 2.f;
    door_size.y = door->door_sprite.getGlobalBounds().width / 2.f;
    door_center_rectangle.setSize(door_size);
    door_center_rectangle.setPosition(door_center);
    if (human->player_sprite.getGlobalBounds().intersects(door_center_rectangle.getGlobalBounds()) &&
        human->grabed_keys_count == 3) {
        return true;
    }
}

void Game::decrease_health_by_bomb(Bomb *bomb) {
    for (int i = 0; i < 5; i++) {
        if (human->player_sprite.getGlobalBounds().intersects(bomb->explosion_area[i].getGlobalBounds())) {
            human->health--;
            if (human->health < 0)
                human->health = 0;
            if (human->health == 0) {
                game_over = true;
            }
            return;
        }
    }
}

void Game::end_game() {
    Texts finish_message;
    if (game_time->seconds_remained == 0 && game_time->minutes_remained == 0 || human->health == 0) {
        game_over = true;
    }
    if (won) {
        music.pause();
        finish_message.message = win_message;
        finish_message.write_message();
        window.draw(finish_message.text);
        game_time->stop();

    }
    if (game_over) {
        music.pause();
        finish_message.message = game_over_message;
        finish_message.write_message();
        window.draw(finish_message.text);
        game_time->stop();
    }
}

void Game::window_sidebar() {
    sidebar_background.setTexture(sidebar_texture);
    sidebar_background.setScale(1, 1);
    sidebar_background.setPosition(sf::Vector2f(1000.f, 0.f)); // Position it at the bottom
    //sidebar_background.setFillColor(sf::Color::Yellow);
    lives_text->write_healths(human->health);
    keys_text->write_grabbed_keys(human->grabed_keys_count);

}

void Game::timer() {
    game_time->remaining_time(game_duration);
    time_text->write_time(game_time->remaining_time_string);
}

void Game::check_h_enemy_collision_with_barriers(Enemy *enemy) {
    for (int i = 0; i < barriers.size(); i++) {
        if (detect_intersection(barriers[i]->barrier_sprite, enemy->h_enemy_sprite) == 'L') {
            enemy->enemy_position.x = barriers[i]->barrier_sprite.getGlobalBounds().left -
                                      barriers[i]->barrier_sprite.getGlobalBounds().width;
            enemy->enemy_velocity.x = -enemy->enemy_velocity.x;
            enemy->h_enemy_sprite.setTexture(enemy->h_enemy_left_texture);
            return;
        } else if (detect_intersection(barriers[i]->barrier_sprite, enemy->h_enemy_sprite) == 'R') {
            enemy->enemy_position.x = barriers[i]->barrier_sprite.getGlobalBounds().left +
                                      barriers[i]->barrier_sprite.getGlobalBounds().width;
            enemy->enemy_velocity.x = -enemy->enemy_velocity.x;
            enemy->h_enemy_sprite.setTexture(enemy->h_enemy_right_texture);
            return;
        }
    }
    for (int j = 0; j < p_barriers.size(); j++) {
        if (detect_intersection(p_barriers[j]->barrier_p_sprite, enemy->h_enemy_sprite) == 'L') {
            enemy->enemy_position.x = p_barriers[j]->barrier_p_sprite.getGlobalBounds().left -
                                      p_barriers[j]->barrier_p_sprite.getGlobalBounds().width;
            enemy->enemy_velocity.x = -enemy->enemy_velocity.x;
            enemy->h_enemy_sprite.setTexture(enemy->h_enemy_left_texture);
            return;

        } else if (detect_intersection(p_barriers[j]->barrier_p_sprite, enemy->h_enemy_sprite) == 'R') {
            enemy->enemy_position.x = p_barriers[j]->barrier_p_sprite.getGlobalBounds().left +
                                      p_barriers[j]->barrier_p_sprite.getGlobalBounds().width;
            enemy->enemy_velocity.x = -enemy->enemy_velocity.x;
            enemy->h_enemy_sprite.setTexture(enemy->h_enemy_right_texture);
            return;
        }
    }
}


void Game::check_v_enemy_collision_with_barriers(Enemy *enemy) {
    for (int i = 0; i < barriers.size(); i++) {
        if (detect_intersection(barriers[i]->barrier_sprite, enemy->v_enemy_sprite) == 'T') {
            enemy->enemy_position.y = barriers[i]->barrier_sprite.getGlobalBounds().top -
                                      barriers[i]->barrier_sprite.getGlobalBounds().width;
            enemy->enemy_velocity.y = -enemy->enemy_velocity.y;
            enemy->v_enemy_sprite.setTexture(enemy->v_enemy_up_texture);
            return;
        } else if (detect_intersection(barriers[i]->barrier_sprite, enemy->v_enemy_sprite) == 'B') {
            enemy->enemy_position.y = barriers[i]->barrier_sprite.getGlobalBounds().top +
                                      barriers[i]->barrier_sprite.getGlobalBounds().width;
            enemy->enemy_velocity.y = -enemy->enemy_velocity.y;
            enemy->v_enemy_sprite.setTexture(enemy->v_enemy_down_texture);
        }
    }
    for (int j = 0; j < p_barriers.size(); j++) {
        if (detect_intersection(p_barriers[j]->barrier_p_sprite, enemy->v_enemy_sprite) == 'T') {
            enemy->enemy_position.y = p_barriers[j]->barrier_p_sprite.getGlobalBounds().top -
                                      p_barriers[j]->barrier_p_sprite.getGlobalBounds().width;
            enemy->enemy_velocity.y = -enemy->enemy_velocity.y;
            enemy->v_enemy_sprite.setTexture(enemy->v_enemy_up_texture);
        } else if (detect_intersection(p_barriers[j]->barrier_p_sprite, enemy->v_enemy_sprite) == 'B') {
            enemy->enemy_position.y = p_barriers[j]->barrier_p_sprite.getGlobalBounds().top +
                                      p_barriers[j]->barrier_p_sprite.getGlobalBounds().width;
            enemy->enemy_velocity.y = -enemy->enemy_velocity.y;
            enemy->v_enemy_sprite.setTexture(enemy->v_enemy_down_texture);
        }
    }
}

void Game::check_player_enemy_collision() {
    for (int i = 0; i < v_enemies.size(); i++) {
        if (human->player_sprite.getGlobalBounds().intersects(v_enemies[i]->enemy_center_rectangle.getGlobalBounds()) &&
            !intersected_v) {
            intersected_v = true;
            intersected_v_enemy = i;
            if (human->health > 0)
                human->health--;
            return;
        } else if (!human->player_sprite.getGlobalBounds().intersects(
                v_enemies[intersected_v_enemy]->enemy_center_rectangle.getGlobalBounds()) && intersected_v)
            intersected_v = false;
    }
    for (int i = 0; i < h_enemies.size(); i++) {
        if (human->player_sprite.getGlobalBounds().intersects(h_enemies[i]->enemy_center_rectangle.getGlobalBounds()) &&
            !intersected_h) {
            intersected_h = true;
            intersected_h_enemy = i;

            if (human->health > 0)
                human->health--;
            return;
        } else if (!human->player_sprite.getGlobalBounds().intersects(
                h_enemies[intersected_h_enemy]->enemy_center_rectangle.getGlobalBounds()) &&
                   intersected_h) {
            intersected_h = false;
        }
    }
}

void Game::load_music() {
    if (!music.openFromFile(music_addr)) {
        music.setVolume(50.f);
    }

}


