//
// Created by mahdi on 12/2/23.
//

#include "Barrier.h"
Barrier::Barrier(){
    load_texture('P');
    load_texture('B');
    load_texture('D');
    create_sprite();
}
bool Barrier::load_texture(char barrier){
    if (barrier == 'B') {
       return barrier_texture.loadFromFile(barrier_addr);
    }
    if (barrier== 'P') {
        return barrier_p_texture.loadFromFile(p_barrier_addr);
    }
    if(barrier == 'D'){
        return door_texture.loadFromFile(door_addr);
    }
}
void Barrier::create_sprite(){
    barrier_sprite.setTexture(barrier_texture);
    barrier_sprite.setScale(static_cast<float>(grid_size) / barrier_texture.getSize().x,
                            static_cast<float>(grid_size) / barrier_texture.getSize().y);
    barrier_p_sprite.setTexture(barrier_p_texture);
    barrier_p_sprite.setScale(static_cast<float>(grid_size) / barrier_p_texture.getSize().x,
                              static_cast<float>(grid_size) / barrier_p_texture.getSize().y);
    door_sprite.setTexture(door_texture);
    door_sprite.setScale(static_cast<float>(grid_size) / door_texture.getSize().x,
                              static_cast<float>(grid_size) / door_texture.getSize().y);
}
