//
// Created by mahdi on 12/4/23.
//

#include "Texts.h"

Texts::Texts() {
    load_font();
}

bool Texts::load_font() {
    if (!font.loadFromFile(font_addr)) {
        std::cout << "could not load font!" << std::endl;
        return false;
    } else
        return true;
}

void Texts::write_message() {
    text.setFont(font);
    text.setString(message);
    text.setCharacterSize(100);
    text.setColor(sf::Color::Cyan);
    text.setPosition(250.f, 250.f);

}

void Texts::Texts::write_time(std::string time_string) {
    remaining_time_text.setFont(font);
    remaining_time_text.setString(time_string);
    remaining_time_text.setCharacterSize(72);
    remaining_time_text.setColor(sf::Color::Red);
    remaining_time_text.setPosition(1050.f,135.f);
}

void Texts::write_healths(int lives_count) {
    std::string lives_count_string = "Lives : " + std::to_string(lives_count);
    lives_count_text.setFont(font);
    lives_count_text.setString(lives_count_string);
    lives_count_text.setCharacterSize(72);
    lives_count_text.setColor(sf::Color::Green);
    lives_count_text.setPosition(1020.f,486.f);
}

void Texts::write_grabbed_keys(int keys_count) {
    std::string keys_count_string = "Keys : "+std::to_string(keys_count);
    keys_count_text.setFont(font);
    keys_count_text.setString(keys_count_string);
    keys_count_text.setCharacterSize(72);
    keys_count_text.setColor(sf::Color::Yellow);
    keys_count_text.setPosition(1030.f,780.f);
}


