//
// Created by mahdi on 12/6/23.
//

#include "Animation.h"

Animation::Animation() {
    load_texture();
    annimations_array();
    create_sprite();
}

bool Animation::load_texture() {
    return animation_texture.loadFromFile(animation_addr);
}

void Animation::create_sprite() {
    animation_sprite.setTexture(animation_texture);
    animation_rect.setSize(sf::Vector2f(50.f, 50.f));
    animation_sprite.setScale(static_cast<float>(grid_size) / animation_texture.getSize().x,
                              static_cast<float>(grid_size) / animation_texture.getSize().y);
}

void Animation::annimations_array() {
    for (int i = 0; i < 10; i++) {
        texture_rects[i] = sf::IntRect(40 - 5 * i, 40 - 5 * i, 20 + 10 * i, 20 + 10 * i);
    }
}


