//
// Created by mahdi on 11/29/23.
//

#include "Bomb.h"
#include "Constants.h"
#include "Animation.h"
//
// Created by mahdi on 11/29/23.
//

Bomb::Bomb() {
    load_textures();
    create_sprite();
    }

bool Bomb::load_textures() {
    return bomb_texture.loadFromFile(bomb_addr);
}

void Bomb::create_sprite() {
    bomb_sprite.setTexture(bomb_texture);
    bomb_sprite.setScale(static_cast<float>(grid_size) / bomb_texture.getSize().x,
                         static_cast<float>(grid_size) / bomb_texture.getSize().y);
}

void Bomb::find_explosion_area() {
    float bomb_right_bound = bomb_position.x + grid_size;
    float bomb_left_bound = bomb_position.x;
    float bomb_top_bound = bomb_position.y;
    float bomb_bottom_bound = bomb_position.y + grid_size;
    sf::RectangleShape left_rectangle;
    sf::RectangleShape right_rectangle;
    sf::RectangleShape top_rectangle;
    sf::RectangleShape bottom_rectangle;
    sf::RectangleShape center_rectangle;

    sf::Vector2f rectangle_size;
    rectangle_size.x = grid_size;
    rectangle_size.y= grid_size;

    left_rectangle.setSize(rectangle_size);
    left_rectangle.setPosition(bomb_position.x - grid_size , bomb_position.y);
    explosion_area.push_back(left_rectangle);
    Animation* exploding_animation_l = new Animation;
    exploding_animation_l->animation_sprite.setPosition(bomb_position.x - grid_size , bomb_position.y);
    exploding_animations.push_back(exploding_animation_l);

    right_rectangle.setSize(rectangle_size);
    right_rectangle.setPosition(bomb_position.x + grid_size , bomb_position.y);
    explosion_area.push_back(right_rectangle);
    Animation* exploding_animation_r = new Animation;
    exploding_animation_r->animation_sprite.setPosition(bomb_position.x + grid_size , bomb_position.y);
    exploding_animations.push_back(exploding_animation_r);

    top_rectangle.setSize(rectangle_size);
    top_rectangle.setPosition(bomb_position.x , bomb_position.y - grid_size);
    explosion_area.push_back(top_rectangle);
    Animation* exploding_animation_t = new Animation;
    exploding_animation_t->animation_sprite.setPosition(bomb_position.x , bomb_position.y - grid_size);
    exploding_animations.push_back(exploding_animation_t);

    bottom_rectangle.setSize(rectangle_size);
    bottom_rectangle.setPosition(bomb_position.x , bomb_position.y + grid_size);
    explosion_area.push_back(bottom_rectangle);
    Animation* exploding_animation_b = new Animation;
    exploding_animation_b->animation_sprite.setPosition(bomb_position.x , bomb_position.y + grid_size);
    exploding_animations.push_back(exploding_animation_b);

    center_rectangle.setSize(rectangle_size);

    center_rectangle.setPosition(bomb_position.x , bomb_position.y);
    explosion_area.push_back(center_rectangle);
    Animation* exploding_animation_c = new Animation;
    exploding_animation_c->animation_sprite.setPosition(bomb_position.x , bomb_position.y);
    exploding_animations.push_back(exploding_animation_c);

}
/*
void updateExplosionAnimation(Animation& explosion_animation) {
    // Increment frame index
    explosion_animation.current_frame++;

    // Wrap frame index to explosion_animation length
    if (explosion_animation.current_frame >= explosion_animation.animation_length) {
        explosion_animation.current_frame = 0;
    }

    // Update elapsed time
    explosion_animation.time_elapsed += clock.


    // Update sprite texture based on current frame index
   // explosion_animation.animation_sprite.setTexture(explosion_animation.texture_rects[explosion_animation.current_frame]);
    explosion_animation.animation_sprite.setTexture(explosion_animation.animation_texture, explosion_animation.texture_rects[explosion_animation.current_frame]);
    // Check if explosion_animation should stop
    if (explosion_animation.time_elapsed.asSeconds() >= explosion_animation.duration) {
        explosion_animation.active = false;
    }
}

*/


