//
// Created by mahdi on 12/1/23.
//

#ifndef HELLO_PLAYER_H
#define HELLO_PLAYER_H

#include <SFML/Graphics.hpp>
#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include "Constants.h"
#include "Bomb.h"

class Player {
public:
    Player() ;

    sf::Sprite player_sprite;
    sf::Texture right_texture;
    sf::Texture left_texture;
    sf::Texture up_texture;
    sf::Texture down_stay_texture;
    sf::Vector2f player_velocity;
    sf::Vector2f player_position;
    float player_speed = player_initial_speed;
    int grabed_keys_count = 0;
    int health = 2;

    void update_player();

    void check_bounds();

    bool load_textures();

    void create_sprites();
    void handle_player_movement() ;
private:

};

#endif //HELLO_PLAYER_H
