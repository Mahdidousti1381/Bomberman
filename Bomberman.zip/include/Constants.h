//
// Created by mahdi on 12/1/23.
//

#ifndef HELLO_CONSTANTS_H
#define HELLO_CONSTANTS_H

#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <iostream>
#include <vector>
#include <algorithm>
#include <string>
#include <cmath>
#include <chrono>
#include <fstream>
#include <random>
#include <time.h>
#include "Time.h"
#include <sstream>

#define player_initial_speed 1.0f
#define player_upgraded_speed 2.0f
#define player_initial_position_x 450
#define player_initial_position_y 400
#define enemies_speed 0.2f
#define bomb_cooldown_duration 0.3f
#define grid_size 50
#define player_grid_size 50
#define bar_window_width 300
#define window_height 1000
#define window_width 1000
#define num_key_barriers 3
#define num_speedups 1
#define num_hearts 2
#define bomb_explosion_time 2000

#define win_message "Now you are \nOut of Matrix!"
#define game_over_message "Stay and\nBuild Iran!"
#define game_name "Escape Iran"

#define bomb_addr "Sprites/bomb.png"
#define door_addr "Sprites/door.png"
#define grass_addr "Sprites/grass.png"
#define heart_addr "Sprites/heart.png"
#define speedup_addr "Sprites/speedup.png"
#define key1_addr "Sprites/key.png"
#define key2_addr "Sprites/key2.png"
#define key3_addr "Sprites/key3.png"
#define barrier_addr "Sprites/soil.png"
#define p_barrier_addr "Sprites/see.png"
#define sidebar_addr "Sprites/sidebar.jpg"
#define ground_text_addr "GroundText.txt"
#define boy_right_addr "Sprites/boy/right.png"
#define boy_left_addr "Sprites/boy/left.png"
#define boy_up_addr "Sprites/boy/up.png"
#define boy_down_addr "Sprites/boy/down-stay.png"
#define font_addr "SourceSans3-Black.ttf"
#define girl_right_addr "Sprites/girl/right.png"
#define girl_left_addr "Sprites/girl/left.png"
#define girl_up_addr "Sprites/girl/up.png"
#define girl_down_addr "Sprites/girl/down-stay.png"
#define animation_addr "Sprites/explosion.png"
#define music_addr "The Pink Panther Theme.wav"

#endif //HELLO_CONSTANTS_H

