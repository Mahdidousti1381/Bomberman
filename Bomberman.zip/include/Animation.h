//
// Created by mahdi on 12/6/23.
//

#ifndef HELLO_ANIMATION_H
#define HELLO_ANIMATION_H

#include "Constants.h"
class Animation {
public:
    Animation();
//private:
    void annimations_array();
    bool load_texture();
    void create_sprite();
    sf::RectangleShape animation_rect;
    sf::IntRect texture_rects[10];
    sf::Texture animation_texture;
    sf::Sprite animation_sprite;
    sf::Time time_elapsed;
    int current_frame;
    int animation_length;
    float duration ;
    bool active;

};


#endif //HELLO_ANIMATION_H
