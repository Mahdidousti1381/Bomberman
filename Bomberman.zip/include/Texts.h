//
// Created by mahdi on 12/4/23.
//

#ifndef HELLO_TEXTS_H
#define HELLO_TEXTS_H

#include "Constants.h"

class Texts {
public:
    Texts();

    void write_message();

    void write_time(std::string time_string);

    void write_healths(int lives_count);

    void write_grabbed_keys(int keys_count);

    std::string message;

    sf::Text text;
    sf::Text remaining_time_text;
    sf::Text lives_count_text;
    sf::Text keys_count_text;

private:

    sf::Font font;

    bool load_font();

};


#endif //HELLO_TEXTS_H
