//
// Created by mahdi on 12/1/23.
//

#ifndef HELLO_GAME_H
#define HELLO_GAME_H

#include "Player.h"
#include "Bomb.h"
#include "Constants.h"
#include <iostream>
#include <vector>
#include "Barrier.h"
#include "Key.h"
#include "Texts.h"
#include "PowerUp.h"
#include "Enemy.h"

class Game {
public:
    Game();

    void run();

private:
    struct Ground {
        char character;
        int row;
        int col;
    };

    void bomber();

    void destroy_barriers_and_enemies(Bomb *bomb);

    void bomb_explosion();

    void load_textures();

    void create_sprites();

    void handleEvents();

    void update_enemies();

    void update();

    void render_background();

    void render_barriers();

    void create_barriers();

    void render_keys();

    void render_powerups();

    void render_enemies();

    void render_animation();
    void render_life_and_keys_count();
    void render();

    void window_size_detector();

    void player_collision_check();

    void check_h_enemy_collision_with_barriers(Enemy* enemy);
    void check_v_enemy_collision_with_barriers(Enemy* enemy);
    void check_player_enemy_collision();
    void manage_player_collision(sf::Sprite barrier);

    char detect_intersection(sf::Sprite barrier, sf::Sprite moving_sprite);

    bool is_verticaly_adjacent(std::vector<float> bounds);

    std::vector<Ground> get_game_ground();

    bool is_horizontaly_adjacent(std::vector<float> bounds);

    void set_keys_position();

    void set_powerup_position();

    void select_random_barriers();

    void grab_key();

    void grab_powerup();

    bool pass_door();

    void decrease_health_by_bomb(Bomb *bomb);

    void end_game();

    void window_sidebar();

    void timer();

    void load_music();

    Barrier *door = new Barrier;
    Player *human = new Player;
    sf::Music music;
    sf::RenderWindow window;
    sf::Texture background_texture;
    sf::Texture sidebar_texture;
    sf::Sprite background_sprite;
    sf::Texture heart_texture;
    sf::Texture key_texture;
    sf::Texture speedup_texture;
    std::vector<Enemy *> v_enemies;
    std::vector<Enemy *> h_enemies;
    std::vector<Barrier *> barriers;
    std::vector<Barrier *> p_barriers;
    std::vector<Bomb *> bombs;
    std::vector<Key *> keys;
    std::vector<Barrier *> selected_barriers_for_keys;
    std::vector<Barrier *> selected_barriers_for_hearts;
    std::vector<Barrier *> selected_barriers_for_speedups;
    std::vector<PowerUp *> hearts;
    sf::Sprite grid_sprite;
    sf::Clock bomb_cooldown;
    sf::Sprite sidebar_background;
    Time *game_time = new Time;
    Texts *time_text = new Texts;
    Texts *lives_text = new Texts;
    Texts *keys_text = new Texts;
    PowerUp *speedup = new PowerUp;
    int intersected_v_enemy=0;
    int intersected_h_enemy=0;
    bool intersected_v= false;
    bool intersected_h= false;
    int max_bombs = 3;
    int num_tiles_x;
    int num_tiles_y;
    int game_time_minutes;
    int game_time_seconds;
    int game_duration;
    int speedups_count = num_speedups;
    bool won = false;
    bool game_over = false;
    std::vector<Ground> WINDOW;

};

#endif //HELLO_GAME_H
