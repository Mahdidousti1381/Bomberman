//
// Created by mahdi on 12/4/23.
//

#ifndef HELLO_TIME_H
#define HELLO_TIME_H

#include "Constants.h"

class Time {
public:
    void start();

    void current();

    double get_elapsed_time();

    void remaining_time(int &game_duration);

    void stop();
    std::string remaining_time_string ;
    int minutes_remained;
    int seconds_remained;
    int remained_time = 120;
private:
    timespec start_time;
    timespec current_time;

};


#endif //HELLO_TIME_H
