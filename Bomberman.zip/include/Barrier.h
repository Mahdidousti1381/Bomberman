//
// Created by mahdi on 12/2/23.
//

#ifndef HELLO_BARRIER_H
#define HELLO_BARRIER_H

#include "Constants.h"

class Barrier {
public:
    Barrier();
    bool load_texture(char barrier);

    void create_sprite();

    sf::Sprite barrier_p_sprite;
    sf::Sprite barrier_sprite;
    sf::Sprite door_sprite;
private:
    sf::Texture barrier_texture;
    sf::Texture barrier_p_texture;
    sf::Texture door_texture;

};


#endif //HELLO_BARRIER_H
