//
// Created by mahdi on 12/3/23.
//

#ifndef HELLO_KEY_H
#define HELLO_KEY_H

#include "Constants.h"

class Key {
public:
    Key(int keynum);

    sf::Sprite key_sprite;


private:
    bool load_texture();

    void create_sprite(int keynum);

    sf::Texture key1_texture;
    sf::Texture key2_texture;
    sf::Texture key3_texture;

};

#endif //HELLO_KEY_H
