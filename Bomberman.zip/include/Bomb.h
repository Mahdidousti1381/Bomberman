//
// Created by mahdi on 11/29/23.
//

#ifndef HELLO_BOMB_H
#define HELLO_BOMB_H

#include "Constants.h"
#include "Bomb.h"
#include "Animation.h"

class Bomb {
public:
    Bomb();

    sf::Sprite bomb_sprite;
    sf::Vector2f bomb_position;
    std::chrono::time_point<std::chrono::system_clock> time_created;
    std::vector<sf::RectangleShape> explosion_area;
    bool is_bomb_placed;

    void find_explosion_area();

    std::vector<Animation *> exploding_animations;

    bool show_animation =false;

private:
    sf::Texture bomb_texture;

    bool load_textures();

    void create_sprite();
};

#endif //HELLO_BOMB_H
