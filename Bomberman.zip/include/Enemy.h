//
// Created by mahdi on 12/5/23.
//

#ifndef HELLO_ENEMY_H
#define HELLO_ENEMY_H

#include "Constants.h"
#include "Barrier.h"
class Enemy {

public:
    Enemy(char enemy_type);

    sf::Sprite v_enemy_sprite;
    sf::Texture v_enemy_up_texture;
    sf::Texture v_enemy_down_texture;
    sf::Sprite h_enemy_sprite;
    sf::Texture h_enemy_left_texture;
    sf::Texture h_enemy_right_texture;
    sf::Vector2f enemy_velocity;
    sf::Vector2f enemy_position;
    sf::RectangleShape enemy_center_rectangle;
    float enenmy_speed = enemies_speed;
    char direction;
    void update_enemy(char enemy_type);
    void handle_enemy_movement();
    //void check_collisions(std::vector<Barrier*> barriers , std::vector<Barrier*> p_barriers);

    bool load_textures(char enemy_type);
    void check_bounds();
private:
    char create_random_vertical_direction();
    char create_random_horizontal_direction();
    void create_sprites(char enemy_type , char vertical_direction , char horizontal_direction) ;
    void set_enemy_center_rectangle();

};


#endif //HELLO_ENEMY_H
