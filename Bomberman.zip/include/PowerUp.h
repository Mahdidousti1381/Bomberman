//
// Created by mahdi on 12/5/23.
//

#ifndef HELLO_POWERUP_H
#define HELLO_POWERUP_H

#include "Constants.h"

class PowerUp {
public:
    sf::Sprite speedup_sprite;
    sf::RectangleShape speedup_center_rectangle;

    sf::Sprite heart_sprite;
    sf::RectangleShape heart_center_rectangle;

    PowerUp() ;
    void create_center_rectangle();

private:


    bool load_texture();

    void create_sprite();

    sf::Texture heart_texture;
    sf::Texture speedup_texture;

};


#endif //HELLO_POWERUP_H
